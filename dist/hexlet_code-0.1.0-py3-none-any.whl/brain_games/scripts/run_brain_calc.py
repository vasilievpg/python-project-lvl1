import brain_games.games.brain_calc
from brain_games.scripts.game_logic import game_logic


def brain_calc():
    game_logic(brain_games.games.brain_calc)


def main():
    brain_calc()


if __name__ == '__main__':
    main()
