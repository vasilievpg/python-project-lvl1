#!/usr/bin/env python

from brain_games.scripts.cli import welcome_user
from brain_games.scripts.brain_even import brain_even
from brain_games.scripts.brain_even import conditions


def main():
    name = welcome_user()
    print(f'Hello, {name}!')


if __name__ == '__main__':
    main()
